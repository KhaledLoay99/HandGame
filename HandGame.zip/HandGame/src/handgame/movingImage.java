/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handgame;


import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Khaled
 */
public class movingImage extends JPanel {
            int x,y=0;
            String music ="C:\\Users\\Khaled\\Desktop\\MUSIC.wav";
            static BufferedImage image;
            static boolean check=true;
            static JLabel MyImage;
           static boolean Break=true;
           static boolean show=true;
           static JPanel p;
           static JButton button1;
           static JButton button2;
           static JButton button3;
           static String Rock="C:\\Users\\Khaled\\Desktop\\ROCK.jpg";
           static String Paper="C:\\Users\\Khaled\\Desktop\\PAPER.jpg";
           static String Scissors="C:\\Users\\Khaled\\Desktop\\SCISSORS.jpg";
           static String[] images = new String[]{Rock,Paper ,Scissors};
           static int index;

            movingImage() throws IOException{
               
                
              this.image=ImageIO.read(new File("C:\\Users\\Khaled\\Desktop\\hand1.png"));
              
               index = (int) (Math.random() * (images.length));
               MyImage = new JLabel(new ImageIcon(images[index]));
               MyImage.setBounds(50, 50, 500, 500);
             
              p=new JPanel();
              p.setBounds(500, 40, 500, 500);
              p.setLayout(null);

      setLayout( null);
       button1 =new JButton("Rock");
       button1.setBounds(40, 500, 100, 100);
       add(button1);
       
        button2 =new JButton("Paper");
       button2.setBounds(190, 500, 100, 100);
       add(button2);
       
        button3 =new JButton("Scissors");
       button3.setBounds(340, 500, 100, 100);
      add(button3);
      
       this.setFocusable(true);
    button1.addActionListener(new press1());
    button2.addActionListener(new press2());
    button3.addActionListener(new press3());

        add(p);

                }
            public void paintComponent(Graphics g){
            
            super.paintComponent(g);
            
            g.drawImage(image,x,y,null);

                
            }
 
     public  void draw() throws InterruptedException, IOException{
         this.setFocusable(true);
       while(true){
         if(check==true ){             
              x+=10;
              if(x==100){
                check=false;
              }
         }
         if(check==false){
             x-=10;
           if(x==0){
               check=true;
           }
         }
         
         repaint();
         if(Break==false){            
             break;
         }
         
         Thread.sleep(60);
       }
     }
       private  static class press1 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
                
                try {
                
                 
                image=ImageIO.read(new File(Rock));
                                Break=false;
                                p.add(MyImage);
               if(e.getSource().equals(button1) && images[index].equals(Paper)){
                   JOptionPane.showMessageDialog(null, "You Lose");
                
                }
               if(e.getSource().equals(button1) && images[index].equals(Scissors)){
                   JOptionPane.showMessageDialog(null, "You Win");
                
                }
                if(e.getSource().equals(button1) && images[index].equals(Rock)){
                   JOptionPane.showMessageDialog(null, "No One Win !Play Again");
                
                }

            } catch (IOException ex) {
                Logger.getLogger(movingImage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
   }
      
      private static  class press2 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            try {

               image=ImageIO.read(new File(Paper));
                Break=false;
                p.add(MyImage);
               if(e.getSource().equals(button2) && images[index].equals(Rock)){
                   JOptionPane.showMessageDialog(null, "You Win");
                
                }
               if(e.getSource().equals(button2) && images[index].equals(Scissors)){
                   JOptionPane.showMessageDialog(null, "You Lose");
                
                }
               if(e.getSource().equals(button2) && images[index].equals(Paper)){
                   JOptionPane.showMessageDialog(null, "No One Win !Play Again");
                
                }
            } catch (IOException ex) {
                Logger.getLogger(movingImage.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }
      }
      
      private   static class press3 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
             try {
               image=ImageIO.read(new File(Scissors));
                Break=false;
                p.add(MyImage);
                
                if(e.getSource().equals(button3) && images[index].equals(Rock)){
                   JOptionPane.showMessageDialog(null, "You Lose");
                
                }
               if(e.getSource().equals(button3) && images[index].equals(Paper)){
                   JOptionPane.showMessageDialog(null, "You Win");
                
                }
               if(e.getSource().equals(button3) && images[index].equals(Scissors)){
                   JOptionPane.showMessageDialog(null, "No One Win !Play Again");
                
                }
            } catch (IOException ex) {
                Logger.getLogger(movingImage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
      }
      
      
}
