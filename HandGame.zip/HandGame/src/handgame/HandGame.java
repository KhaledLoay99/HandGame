/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handgame;



import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


/**
 *
 * @author Khaled
 */
public class HandGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, IOException, LineUnavailableException, UnsupportedAudioFileException {
        // TODO code application logic here
        
        JFrame f=new JFrame();
       f.setBounds(0, 0, 1200, 900);
       movingImage m=new movingImage();
       AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(m.music).getAbsoluteFile());
        Clip clip = AudioSystem.getClip();
        clip.open(audioInputStream);
        clip.start();
        clip.loop(100);
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
       f.add(m);
       f.setVisible(true); 
       m.draw();
       clip.stop();
 
    }
    
    }


